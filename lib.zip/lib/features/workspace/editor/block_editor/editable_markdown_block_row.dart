part of 'package:folio/features/workspace/editor/block_editor.dart';

Widget _buildEditableMarkdownBlockRow(_BlockRowScope s) {
  final st = s.st;
  final block = s.block;
  final page = s.page;
  final scheme = s.scheme;
  final theme = s.theme;
  final context = s.context;
  final ctrl = s.ctrl;
  final focus = s.focus;
  final marker = s.marker;
  final dragHandle = s.dragHandle;
  final menu = s.menu;
  final l10n = AppLocalizations.of(context);
  final showActions = s.showActions;
  final style = s.style;
  final compactReadOnlyMobile = s.compactReadOnlyMobile;
  final readOnlyMode = s.readOnlyMode;
  final appSettings = s.appSettings;
  final isParagraph = block.type == 'paragraph';
  final isListLine =
      block.type == 'todo' ||
      block.type == 'bullet' ||
      block.type == 'numbered';
  final isTopAlignedSlashBlock =
      isParagraph ||
      isListLine ||
      block.type == 'toggle' ||
      block.type == 'quote' ||
      block.type == 'callout';

  final isWysiwygBlock = _stylableBlockTypes.contains(block.type);
  final quillCtrl = isWysiwygBlock && !readOnlyMode
      ? st._ensureQuillController(pageId: page.id, block: block)
      : null;
  final plainForMenus = quillCtrl != null
      ? quillCtrl.document.toPlainText()
      : ctrl.text;
  final selForMenus = quillCtrl != null ? quillCtrl.selection : ctrl.selection;

  final allowsSlash = blockEditorTypeUsesSlashMenu(block.type);
  final String? slashTail = allowsSlash
      ? ((_slashFilterFromPlainTextAndSelection(plainForMenus, selForMenus)) ??
            _slashFilterFromBlockText(plainForMenus))
      : null;
  final showSlashMenu = slashTail != null && st._slashBlockId == block.id;
  final slashItems = showSlashMenu
      ? st._catalogFilteredForSlash(slashTail)
      : const <BlockTypeDef>[];
  final mentionTail = allowsSlash
      ? _mentionFilterFromSelection(plainForMenus, selForMenus)
      : null;
  final showMentionMenu =
      !showSlashMenu && mentionTail != null && st._mentionBlockId == block.id;
  final mentionItems = showMentionMenu
      ? st._catalogFilteredForMention(mentionTail)
      : const <FolioPage>[];
  final slashPanelMaxH = math.min(
    192.0,
    math.max(100.0, MediaQuery.sizeOf(context).height * 0.25),
  );

  /// Vista previa mientras no está enfocado: el markdown queda interactivo
  /// para que los enlaces se puedan pulsar sin entrar antes en edición.
  /// Un toque fuera de un enlace vuelve a enfocar el editor.
  /// Sin previa si solo hay `#`…`######` y espacios (el render no muestra nada útil).
  final showInlinePreview =
      allowsSlash &&
      !readOnlyMode &&
      !focus.hasFocus &&
      ctrl.text.trim().isNotEmpty &&
      !BlockEditorState._isIncompleteAtxHeadingLine(ctrl.text);

  var currentStyle = style;
  if (block.type == 'quote') {
    currentStyle = currentStyle.copyWith(
      fontStyle: FontStyle.italic,
      fontSize: currentStyle.fontSize! * 1.05,
      color: scheme.onSurface.withValues(alpha: 0.8),
    );
  }
  currentStyle = st._applyBlockAppearanceToTextStyle(
    currentStyle,
    scheme,
    block,
  );
  final appearance = st._blockAppearanceFor(block);
  final customBackground = st._blockBackgroundColorFor(
    scheme,
    appearance.backgroundRole,
  );
  final customBackgroundBorder = st._blockBackgroundBorderColorFor(
    scheme,
    appearance.backgroundRole,
  );

  final mdSheet = folioMarkdownStyleSheet(context, currentStyle, scheme);

  final field = isWysiwygBlock
      ? () {
          final c =
              quillCtrl ??
              quill.QuillController(
                document: FolioMarkdownQuillCodec.markdownToDocument(ctrl.text),
                selection: const TextSelection.collapsed(offset: 0),
              );
          c.readOnly = readOnlyMode;

          final editor = quill.QuillEditor.basic(
            controller: c,
            focusNode: focus,
            scrollController: st._folioQuillMainScrollFor(block.id),
            config: quill.QuillEditorConfig(
              expands: false,
              padding: EdgeInsets.zero,
              scrollable: false,
              autoFocus: false,
            ),
          );

          // Importante: mantener el QuillEditor SIEMPRE montado (misma
          // estructura), para evitar unmount mientras Quill tiene callbacks de
          // foco/IME pendientes (crash en Windows).
          final showPreviewOverlay =
              !readOnlyMode && !focus.hasFocus && allowsSlash;
          // Preview sin foco:
          // - Debajo: Quill (readOnly) para conservar estilos avanzados (color/fondo/highlight).
          // - Encima: Markdown preview para hit-testing de links internos (folio://open/...)
          //   y para conservar comportamiento previo. El texto normal se hace
          //   transparente para no tapar el render WYSIWYG; los links se mantienen
          //   visibles/clicables.
          final mdSheetTransparent = mdSheet.copyWith(
            p: mdSheet.p?.copyWith(color: Colors.transparent),
            strong: mdSheet.strong?.copyWith(color: Colors.transparent),
            em: mdSheet.em?.copyWith(color: Colors.transparent),
            del: mdSheet.del?.copyWith(color: Colors.transparent),
            code: mdSheet.code?.copyWith(color: Colors.transparent),
            // Links visibles para que el usuario sepa dónde clicar.
            a: mdSheet.a,
          );

          return Stack(
            children: [
              Opacity(
                opacity: showPreviewOverlay ? 0 : 1,
                child: IgnorePointer(
                  ignoring: showPreviewOverlay,
                  child: editor,
                ),
              ),
              if (showPreviewOverlay)
                Positioned.fill(
                  child: Stack(
                    children: [
                      Align(
                        alignment: isTopAlignedSlashBlock
                            ? AlignmentDirectional.topStart
                            : AlignmentDirectional.centerStart,
                        child: quill.QuillEditor.basic(
                          controller: c..readOnly = true,
                          focusNode: FocusNode(skipTraversal: true),
                          scrollController:
                              st._folioQuillPreviewScrollFor(block.id),
                          config: const quill.QuillEditorConfig(
                            expands: false,
                            padding: EdgeInsets.zero,
                            scrollable: false,
                            autoFocus: false,
                            showCursor: false,
                            enableInteractiveSelection: false,
                          ),
                        ),
                      ),
                      Positioned.fill(
                        child: Align(
                          alignment: isTopAlignedSlashBlock
                              ? AlignmentDirectional.topStart
                              : AlignmentDirectional.centerStart,
                          child: FolioMarkdownPreview(
                            data: ctrl.text,
                            styleSheet: mdSheetTransparent,
                            onFolioPageLink: st._s.selectPage,
                          ),
                        ),
                      ),
                      // Tap en cualquier zona no-link: entrar en edición.
                      Positioned.fill(
                        child: GestureDetector(
                          behavior: HitTestBehavior.translucent,
                          onTap: () => focus.requestFocus(),
                        ),
                      ),
                    ],
                  ),
                ),
            ],
          );
        }()
      : TextField(
          controller: ctrl,
          focusNode: focus,
          readOnly: readOnlyMode,
          showCursor: !readOnlyMode,
          maxLines: null,
          minLines: 1,
          cursorColor: scheme.onSurface,
          style: showInlinePreview
              ? currentStyle.copyWith(
                  color: Colors.transparent,
                  decoration: TextDecoration.none,
                )
              : currentStyle,
          onTap: readOnlyMode
              ? null
              : () {
                  focus.requestFocus();
                },
          textAlignVertical: isTopAlignedSlashBlock
              ? TextAlignVertical.top
              : TextAlignVertical.center,
          decoration: isListLine
              ? InputDecoration.collapsed(
                  hintText: block.type == 'todo'
                      ? l10n.blockEditorTodoPlaceholder
                      : '',
                )
              : InputDecoration(
                  border: InputBorder.none,
                  isDense: true,
                  filled: false,
                  hintText: isParagraph
                      ? 'Escribe…  /  para tipos de bloque'
                      : null,
                  contentPadding: EdgeInsets.zero,
                ),
        );

  final stackedField = showInlinePreview && !isWysiwygBlock
      ? Stack(
          children: [
            // Mantener el TextField en el árbol (aunque sea invisible) para que
            // el FocusNode esté adjunto y un click pueda entrar en edición.
            field,
            Positioned.fill(
              child: Align(
                alignment: isTopAlignedSlashBlock
                    ? AlignmentDirectional.topStart
                    : AlignmentDirectional.centerStart,
                child: FolioMarkdownPreview(
                  data: ctrl.text,
                  styleSheet: mdSheet,
                  onFolioPageLink: st._s.selectPage,
                ),
              ),
            ),
          ],
        )
      : field;

  final readOnlyMarkdown = FolioMarkdownPreview(
    data: ctrl.text,
    styleSheet: mdSheet,
    onFolioPageLink: st._s.selectPage,
  );

  final blockContent = readOnlyMode && allowsSlash
      ? readOnlyMarkdown
      : KeyedSubtree(
          key: st._formatToolbarHostKeyFor(block.id),
          child: stackedField,
        );

  Widget textContainer = blockContent;
  if (block.type == 'quote') {
    textContainer = Container(
      padding: EdgeInsets.fromLTRB(
        12,
        customBackground != null ? 8 : 2,
        customBackground != null ? 12 : 0,
        customBackground != null ? 8 : 2,
      ),
      decoration: BoxDecoration(
        color: customBackground,
        borderRadius: customBackground != null
            ? BorderRadius.circular(12)
            : null,
        border: Border(
          left: BorderSide(color: scheme.outlineVariant, width: 4),
        ),
      ),
      child: blockContent,
    );
  } else if (block.type == 'callout') {
    final calloutTone = calloutToneForIcon(block.icon);
    textContainer = Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color:
            customBackground ?? calloutBackgroundForTone(scheme, calloutTone),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: customBackground != null
              ? customBackgroundBorder
              : calloutBorderForTone(scheme, calloutTone),
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(right: 10),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  decoration: BoxDecoration(
                    color: calloutChipForTone(scheme, calloutTone),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 5,
                    ),
                    child: MouseRegion(
                      cursor: readOnlyMode
                          ? MouseCursor.defer
                          : SystemMouseCursors.click,
                      child: GestureDetector(
                        onTap: readOnlyMode
                            ? null
                            : () async {
                                final emoji = await st._pickEmoji(context);
                                if (emoji != null) {
                                  st._s.updateBlockIcon(
                                    page.id,
                                    block.id,
                                    emoji,
                                  );
                                }
                              },
                        child: FolioIconTokenView(
                          appSettings: appSettings,
                          token: block.icon,
                          fallbackText: '💡',
                          size: 22,
                        ),
                      ),
                    ),
                  ),
                ),
                PopupMenuButton<String>(
                  tooltip: l10n.calloutTypeTooltip,
                  enabled: !readOnlyMode,
                  onSelected: readOnlyMode
                      ? null
                      : (emoji) =>
                            st._s.updateBlockIcon(page.id, block.id, emoji),
                  itemBuilder: (ctx) => [
                    PopupMenuItem(
                      value: '💡',
                      child: Text('💡 ${l10n.calloutTypeInfo}'),
                    ),
                    PopupMenuItem(
                      value: '✅',
                      child: Text('✅ ${l10n.calloutTypeSuccess}'),
                    ),
                    PopupMenuItem(
                      value: '⚠️',
                      child: Text('⚠️ ${l10n.calloutTypeWarning}'),
                    ),
                    PopupMenuItem(
                      value: '🚨',
                      child: Text('🚨 ${l10n.calloutTypeError}'),
                    ),
                    PopupMenuItem(
                      value: 'ℹ️',
                      child: Text('ℹ️ ${l10n.calloutTypeNote}'),
                    ),
                  ],
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(
                    minWidth: 34,
                    minHeight: 36,
                  ),
                  child: Icon(
                    Icons.arrow_drop_down,
                    color: scheme.onSurfaceVariant,
                  ),
                ),
              ],
            ),
          ),
          Expanded(child: blockContent),
        ],
      ),
    );
  } else if (customBackground != null) {
    textContainer = Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: customBackground,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: customBackgroundBorder),
      ),
      child: blockContent,
    );
  }

  /// La barra de formato va en un [Overlay] anclado a la selección
  /// ([BlockEditorState._updateFormatToolbarOverlay]).
  final Widget editorSlot = textContainer;

  final Widget textSlot;
  if (showSlashMenu) {
    final tail = slashTail;
    textSlot = Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      mainAxisSize: MainAxisSize.min,
      children: [
        editorSlot,
        Padding(
          padding: const EdgeInsets.only(top: FolioSpace.xs),
          child: BlockEditorFloatingPanel(
            scheme: scheme,
            child: ConstrainedBox(
              constraints: BoxConstraints(
                maxHeight: slashPanelMaxH,
                minHeight: slashItems.isEmpty ? 48 : 72,
              ),
              child: slashItems.isEmpty
                  ? Center(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 12),
                        child: Text(
                          l10n.blockEditorSlashNoMatches,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: theme.textTheme.bodySmall?.copyWith(
                            color: scheme.onSurfaceVariant,
                          ),
                        ),
                      ),
                    )
                  : Scrollbar(
                      controller: st._slashListScrollController,
                      interactive: false,
                      thumbVisibility: true,
                      thickness: 3,
                      radius: const Radius.circular(3),
                      child: BlockEditorInlineSlashList(
                        scrollController: st._slashListScrollController,
                        theme: theme,
                        scheme: scheme,
                        items: slashItems,
                        selectedIndex: slashItems.isEmpty
                            ? 0
                            : st._slashSelectedIndex.clamp(
                                0,
                                slashItems.length - 1,
                              ),
                        showSections: tail.trim().isEmpty,
                        onPick: st._applyInlineSlashChoice,
                      ),
                    ),
            ),
          ),
        ),
      ],
    );
  } else if (showMentionMenu) {
    textSlot = Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      mainAxisSize: MainAxisSize.min,
      children: [
        editorSlot,
        Padding(
          padding: const EdgeInsets.only(top: FolioSpace.xs),
          child: BlockEditorFloatingPanel(
            scheme: scheme,
            child: ConstrainedBox(
              constraints: BoxConstraints(
                maxHeight: slashPanelMaxH,
                minHeight: mentionItems.isEmpty ? 48 : 72,
              ),
              child: mentionItems.isEmpty
                  ? Center(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 12),
                        child: Text(
                          l10n.noPages,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: theme.textTheme.bodySmall?.copyWith(
                            color: scheme.onSurfaceVariant,
                          ),
                        ),
                      ),
                    )
                  : Scrollbar(
                      controller: st._mentionListScrollController,
                      interactive: false,
                      thumbVisibility: true,
                      thickness: 3,
                      radius: const Radius.circular(3),
                      child: BlockEditorInlineMentionList(
                        scrollController: st._mentionListScrollController,
                        theme: theme,
                        scheme: scheme,
                        items: mentionItems,
                        selectedIndex: mentionItems.isEmpty
                            ? 0
                            : st._mentionSelectedIndex.clamp(
                                0,
                                mentionItems.length - 1,
                              ),
                        onPick: st._applyInlineMentionChoice,
                      ),
                    ),
            ),
          ),
        ),
      ],
    );
  } else {
    textSlot = editorSlot;
  }

  return BlockRowChrome(
    depth: block.depth,
    compactReadOnlyMobile: compactReadOnlyMobile,
    crossAxisAlignment: isTopAlignedSlashBlock
        ? CrossAxisAlignment.start
        : CrossAxisAlignment.center,
    menuSlot: st._blockMenuSlot(showActions: showActions, menu: menu),
    dragHandle: dragHandle,
    marker: marker,
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        textSlot,
        if (block.syncGroupId != null)
          Padding(
            padding: const EdgeInsets.only(top: 2, bottom: 2),
            child: Builder(
              builder: (ctx) {
                final syncScheme = Theme.of(ctx).colorScheme;
                final count = st._s.syncGroupBlockCount(block.syncGroupId!);
                return Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      Icons.sync_rounded,
                      size: 11,
                      color: syncScheme.primary.withAlpha(180),
                    ),
                    const SizedBox(width: 3),
                    Text(
                      count > 1
                          ? AppLocalizations.of(
                              ctx,
                            ).syncedBlockGroupCount(count)
                          : AppLocalizations.of(ctx).syncedBlockBadge,
                      style: TextStyle(
                        fontSize: 10,
                        color: syncScheme.primary.withAlpha(180),
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                );
              },
            ),
          ),
      ],
    ),
  );
}
