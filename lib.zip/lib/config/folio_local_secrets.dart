/// Secretos locales de desarrollo: **aquí es donde deben vivir** los valores
/// que no quieres versionar (OAuth Jira, integración, etc.).
///
/// **No versionar valores reales.** Copia `folio_local_secrets.example.dart` a
/// `lib/config/folio_local_secrets.dart` y rellénalo (ese archivo está en
/// `.gitignore`). En **web** no hay lectura de `.env` en disco: usa este archivo
/// o `--dart-define` al compilar.
///
/// Prioridad: `--dart-define` > este archivo > `.env` / [LocalEnv] (solo
/// escritorio/móvil con dart:io) > variables de entorno del proceso.
abstract final class FolioLocalSecrets {
  static const String jiraOAuthClientId = '7HEIa3N2dGmMWWscFmYnjGRLNSjzg8hI';
  static const String jiraOAuthClientSecret = 'ATOAzIXo1GbFCkUceJ8WbqexWMQP1FsWphAg4_ies8m7IjlRPoid0n2EYSC0I29ns5tY6BE2D580';

  /// Id de producto en Microsoft Store (ficha pública de la app).
  /// Listado: https://apps.microsoft.com/detail/9NR921QXGNHF
  static const String microsoftStoreListingProductId = '9NR921QXGNHF';

  /// Mismas claves que `String.fromEnvironment` y las entradas de `.env`.
  static String valueForDefineKey(String key) {
    switch (key) {
      case 'JIRA_OAUTH_CLIENT_ID':
        return jiraOAuthClientId.trim();
      case 'JIRA_OAUTH_CLIENT_SECRET':
        return jiraOAuthClientSecret.trim();
      case 'FOLIO_MS_STORE_LISTING_PRODUCT_ID':
        return microsoftStoreListingProductId.trim();
      default:
        return '';
    }
  }
}
